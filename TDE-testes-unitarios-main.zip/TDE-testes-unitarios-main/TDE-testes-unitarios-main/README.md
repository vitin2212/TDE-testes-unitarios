TDE consiste no aprimoramento do App da Calculadora, implementando testes unitários de soma,subtração,etc. Nomes: Victor Luis e Bryan.
